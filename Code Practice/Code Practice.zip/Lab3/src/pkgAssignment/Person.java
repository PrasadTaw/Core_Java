package pkgAssignment;

public class Person {
	
	private int id;
	private String name;
	

}
