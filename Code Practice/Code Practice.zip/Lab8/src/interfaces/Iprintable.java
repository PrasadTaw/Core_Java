package interfaces;

public interface Iprintable {
	
	void print(); //Abstract method

}
